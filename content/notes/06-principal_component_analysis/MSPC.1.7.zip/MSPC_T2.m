function varargout = MSPC_T2(varargin)
% MSPC_T2 M-file for MSPC_T2.fig
%      MSPC_T2, by itself, creates a new MSPC_T2 or raises the existing
%      singleton*.
%
%      H = MSPC_T2 returns the handle to a new MSPC_T2 or the handle to
%      the existing singleton*.
%
%      MSPC_T2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MSPC_T2.M with the given input arguments.
%
%      MSPC_T2('Property','Value',...) creates a new MSPC_T2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MSPC_T2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MSPC_T2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MSPC_T2

% Last Modified by GUIDE v2.5 26-Mar-2017 16:21:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MSPC_T2_OpeningFcn, ...
                   'gui_OutputFcn',  @MSPC_T2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MSPC_T2 is made visible.
function MSPC_T2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MSPC_T2 (see VARARGIN)

% Choose default command line output for MSPC_T2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%% Hotelling's T2 chart ...
mainGuiInput = find(strcmp(varargin, 'title'));
sTitle = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'phase'));
phase = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 't'));
handles.t = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'T'));
handles.T = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'Tsquared'));
Tsquared = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'UCL_T2_01'));
UCL_T2_01 = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'UCL_T2_05'));
UCL_T2_05 = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'P'));
handles.P = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'L'));
handles.L = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'A'));
handles.A = varargin{mainGuiInput+1};
set(handles.lblNumberPCs,'string',['Number of selected PCs: ' num2str(handles.A)]);
mainGuiInput = find(strcmp(varargin, 'Xnew'));
handles.X = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'VariableNames'));
VariableNames = varargin{mainGuiInput+1};
handles.VariableNames = VariableNames(:);
mainGuiInput = find(strcmp(varargin, 'IdRemovedObs'));
idRemovedObs = [];
if ~isempty(mainGuiInput)
    idRemovedObs = varargin{mainGuiInput+1};
end

tTemp = handles.t(1:size(Tsquared,2));
plot(handles.axes_T2,tTemp,Tsquared,'b-d','MarkerSize',5,'MarkerFaceColor','b');
hold(handles.axes_T2,'on');
if ~isempty(idRemovedObs)
    % Plot removed obs in red ..
    indRemovedObs = ismember(tTemp,idRemovedObs);
    plot(handles.axes_T2,tTemp(indRemovedObs),Tsquared(indRemovedObs),'r*','MarkerSize',5);
end
axis(handles.axes_T2,[tTemp(1) tTemp(end) min(Tsquared) max(Tsquared)]);
axis(handles.axes_T2,'auto y');
set(gcf,'Name',sTitle);
axes(handles.axes_T2)
xlabel('t');
ylabel('T2');
line([tTemp(1) tTemp(end)], [UCL_T2_01 UCL_T2_01],'Color','r','LineStyle','--','LineWidth',1);
line([tTemp(1) tTemp(end)], [UCL_T2_05 UCL_T2_05],'Color','r','LineStyle','-','LineWidth',1);
grid(handles.axes_T2,'on');
grid(handles.axes_T2,'minor');
hold(handles.axes_T2,'off');

hdt = datacursormode;
set(hdt,'DisplayStyle','window');
% Declare a custom datatip update function to display data:
set(hdt,'UpdateFcn',{@labeldtips,handles,phase,UCL_T2_01,UCL_T2_05})

if phase==1
    pos = get(gcf, 'Position');
    pos(3) = 122;
    set(gcf, 'Position', pos);
end
set(gcf, 'Resize', 'off');

set(handles.cmbScore,'string',{1:handles.A});
guidata(hObject, handles);

% UIWAIT makes MSPC_T2 wait for user response (see UIRESUME)
% uiwait(handles.figT2chart);

%uiwait(hObject);


% --- Outputs from this function are returned to the command line.
function varargout = MSPC_T2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function output_txt = labeldtips(obj,event_obj,handles,phase,UCL_T2_01,UCL_T2_05)
% Display an observation's Y-data and label for a data tip
% obj          Currently not used (empty)
% event_obj    Handle to event object
% xydata       Entire data matrix
% labels       State names identifying matrix row
% xymean       Ratio of y to x mean (avg. for all obs.)
% output_txt   Datatip text (string or string cell array)
% This datacursor callback calculates a deviation from the
% expected value and displays it, Y, and a label taken
% from the cell array 'labels'; the data matrix is needed
% to determine the index of the x-value for looking up the
% label for that row. X values could be output, but are not.

c_axes = get(event_obj.Target,'Parent');
if c_axes==handles.axes_T2
    pos = event_obj.Position;
    x = pos(1);
    y = pos(2);
    output_txt = {['t = ' num2str(x) ' min; T2 = ' num2str(y,4)]};
    if y > UCL_T2_05
        output_txt{end+1} = ['Out of control'];
    elseif y > UCL_T2_01
        output_txt{end+1} = ['Out of control'];
    end

    if phase==2
        handles.idObs = find(handles.t==x);
        guidata(handles.cmbScore, handles);
        PlotNormalizedScores(handles);
    end
elseif c_axes==handles.axes_Cont
    pos = event_obj.Position;
    x = pos(1);
    y = pos(2);
    output_txt = {['cont(' handles.VariableNames{x} ') = ' num2str(y,4)]};
end


% --- Executes during object creation, after setting all properties.
function figT2chart_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figT2chart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


function PlotNormalizedScores(handles)
T = handles.T;
L = handles.L;
t = handles.t;
A = handles.A;

idObs = handles.idObs;

% Phase II.Contribution to Hotelling's T2
% If the abnormal observation is detected by the T2 chart the diagnosis procedure is carried out in two steps:
%    1)	A bar plot of the normalized scores (t2/L) for that observation is plotted and the 'a' score with the highest 
%       normalized value is selected.
Tbar = T(idObs,1:A);
NormScores = Tbar.^2 ./ L(1:A)';
hBar = bar(handles.axes_NormScores,NormScores);
% Color normalizaed scores:
%    Positive --> green
%    Negative --> red
colormap(handles.axes_NormScores,[0 1 0;1 0 0]);
chBar = get(hBar,'Children');
set(chBar,'CData',NormScores);
set(chBar,'CDataMapping','direct');
cIndex = zeros(size(Tbar));
for ib=1:length(Tbar)
    if Tbar(ib)>=0
        cIndex(ib)=1;
    else
        cIndex(ib)=2;
    end
end
set(chBar,'CData',cIndex);
% By default, the contributions for the greatest normalized score are
% plotted ...
set(handles.cmbScore,'Value', find(NormScores==max(NormScores),1,'first'));

%    2) Then, the contribution of each original 'k' variable to this 'a' score at this new abnormal observation is ...
PlotContribution(handles)

function PlotContribution(handles)
P = handles.P;
X = handles.X;
T = handles.T;
L = handles.L;
idObs = handles.idObs;
a = get(handles.cmbScore,'value');
%    2) The contribution of each original 'k' variable to this 'a' score at this new abnormal observation is given by
for k=1:size(P)
    cont(k) = P(k,a) * X(idObs,k);
end
hBar = bar(handles.axes_Cont,cont);
% Color normalizaed scores:
%    Positive --> green
%    Negative --> red
colormap(handles.axes_Cont,[0 1 0;1 0 0]);
chBar = get(hBar,'Children');
set(chBar,'CData',cont);
set(chBar,'CDataMapping','direct');
cIndex = zeros(size(cont));
for k=1:length(cont)
    if cont(k)>=0
        cIndex(k)=1;
    else
        cIndex(k)=2;
    end
end
set(chBar,'CData',cIndex);

LabelVariables(handles)
grid(handles.axes_Cont,'on');



function LabelVariables(handles)
VariableNames = handles.VariableNames;
set(handles.axes_Cont,'fontsize',8);
ylabel(handles.axes_Cont,'Contribution')
% Set the X-Tick locations ...
nVars = length(VariableNames);
Xt = 1:nVars;
Xl = [1 nVars];
set(handles.axes_Cont,'XTick',Xt,'XLim',Xl);
% Check Matlab version
v = sscanf (version, '%d.%d.%d');
if v(1)<8 || (v(1)==8 && v(2)<4)
    % Before R2014b
    ax = axis(handles.axes_Cont);
    axis(axis); % Set the axis limit modes (e.g. XLimMode) to manual
    Yl = ax(3:4); % Y-axis limits
    % Place the text labels
    t = text(Xt,((Yl(1)-(Yl(2)-Yl(1))/50))*ones(1,length(Xt))*1.05,VariableNames, 'Parent',handles.axes_Cont,'FontSize',8);
    set(t,'HorizontalAlignment','right','VerticalAlignment','middle', 'Rotation',90);
    % Remove the default labels
    set(handles.axes_Cont,'XTickLabel','')
    % Get the Extent of each text object. This loop is unavoidable.
    for i = 1:length(t)
        ext(i,:) = get(t(i),'Extent');
    end
    % Determine the lowest point. The X-label will be placed so that the top is aligned with this point.
    LowYPoint = min(ext(:,2));
    % Place the axis label at this point
    XMidPoint = Xl(1)+abs(diff(Xl))/2;
    tl = text(XMidPoint,LowYPoint,'Variables', 'VerticalAlignment','top', 'HorizontalAlignment','center', 'Parent',handles.axes_Cont);
else
    % R2014b and later
    set(handles.axes_Cont,'XTickLabel',VariableNames, ...
                          'XTickLabelRotation',  90);
end

% --- Executes on selection change in cmbScore.
function cmbScore_Callback(hObject, eventdata, handles)
% hObject    handle to cmbScore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cmbScore contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cmbScore
PlotContribution(handles);


% --- Executes during object creation, after setting all properties.
function cmbScore_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmbScore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
