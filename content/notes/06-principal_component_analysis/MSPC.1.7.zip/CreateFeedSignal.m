function wave = CreateFeedSignal(tSim,tSample,type,initialValue,ChangeRatio,ChangePeriod)
%the change is computed from the last value, but the new value cannot
%exceed n times the maximum ChangeRatio
nTimesRatio = 2;
maxChange = initialValue*(nTimesRatio*ChangeRatio);
minChange = 2*initialValue-maxChange;
tSignal = 0:tSample:tSim;
wsSignal = initialValue * ones(length(tSignal),1);
lastValue = initialValue;
for t=ChangePeriod:ChangePeriod:tSim
    n = -ChangeRatio + (2*ChangeRatio*rand(1));
    nextValue = lastValue * (1+n/100);
    if nextValue > maxChange
        nextValue = maxChange;
    elseif nextValue < minChange
        nextValue = minChange;
    end
    switch type
        case 2 %Ramp
            tMax = t+ChangePeriod;
            tAsc = t:tSample:tMax;
            ind1 = fix(t/tSample)+1;
            ind2 = fix(tMax/tSample)+1;
            pte = (nextValue-lastValue)/ChangePeriod;
            r = lastValue + pte*(tAsc-t);
            if ind2-ind1+1 > length(r)
                ind2 = length(r)+ind1-1;
            end
            for i=ind1:1:ind2
                wsSignal(i) = r(i-ind1+1);
            end
            wsSignal(ind2+1:end) = nextValue;
            lastValue = nextValue;
        case 3 %Half ramp: ends with a steady part
            tMax = t+ChangePeriod/2;
            tAsc = t:tSample:tMax;
            ind1 = fix(t/tSample)+1;
            ind2 = fix(tMax/tSample)+1;
            pte = (nextValue-lastValue)/ChangePeriod;
            r = lastValue + pte*(tAsc-t);
            if ind2-ind1+1 > length(r)
                ind2 = length(r)+ind1-1;
            end
            for i=ind1:1:ind2
                wsSignal(i) = r(i-ind1+1);
            end
            %Steady part ...
            ind1 = fix((t+ChangePeriod/2)/tSample)+1;
            ind2 = fix((t+ChangePeriod)/tSample)+1;
            for i=ind1:1:ind2
                wsSignal(i) = nextValue;
            end
            wsSignal(ind2+1:end) = nextValue;
            lastValue = nextValue;
    end
end

wave = [tSignal' wsSignal(1:size(tSignal',1))];
