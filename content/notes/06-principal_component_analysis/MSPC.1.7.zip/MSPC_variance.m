function varargout = MSPC_variance(varargin)
% MSPC_VARIANCE M-file for MSPC_variance.fig
%      MSPC_VARIANCE, by itself, creates a new MSPC_VARIANCE or raises the existing
%      singleton*.
%
%      H = MSPC_VARIANCE returns the handle to a new MSPC_VARIANCE or the handle to
%      the existing singleton*.
%
%      MSPC_VARIANCE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MSPC_VARIANCE.M with the given input arguments.
%
%      MSPC_VARIANCE('Property','Value',...) creates a new MSPC_VARIANCE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MSPC_variance_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MSPC_variance_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MSPC_variance

% Last Modified by GUIDE v2.5 06-Jul-2014 12:54:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MSPC_variance_OpeningFcn, ...
                   'gui_OutputFcn',  @MSPC_variance_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MSPC_variance is made visible.
function MSPC_variance_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MSPC_variance (see VARARGIN)

% Choose default command line output for MSPC_variance
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%% Variance explained by PCs
mainGuiInput = find(strcmp(varargin, 'title'));
sTitle = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'A'));
A = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'pVar'));
pVar = varargin{mainGuiInput+1};

set(gcf,'Name',sTitle);
set(gcf,'CurrentAxes',handles.axes_Variance)
pareto(handles.axes_Variance,pVar);
xlabel('Principal Component');
ylabel('Variance Explained (%)');
line([0 20], [90 90],'Color','r','LineStyle','-','LineWidth',1);
grid(gca,'on');
set(handles.txtNumberPCs,'string',['Number of selected PCs: ' num2str(A)]);
set(handles.grdVariance,'ColumnName',{'Variance','Cumulated Var.'});
set(handles.grdVariance,'Data',[pVar cumsum(pVar)]);

% UIWAIT makes MSPC_variance wait for user response (see UIRESUME)
% uiwait(handles.MSPC_variance);

%uiwait(hObject);


% --- Outputs from this function are returned to the command line.
function varargout = MSPC_variance_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function axes_Variance_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_Variance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_Variance


% --- Executes during object creation, after setting all properties.
function MSPC_variance_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MSPC_variance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
