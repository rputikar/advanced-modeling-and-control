function varargout = MSPC_SPE(varargin)
% MSPC_SPE M-file for MSPC_SPE.fig
%      MSPC_SPE, by itself, creates a new MSPC_SPE or raises the existing
%      singleton*.
%
%      H = MSPC_SPE returns the handle to a new MSPC_SPE or the handle to
%      the existing singleton*.
%
%      MSPC_SPE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MSPC_SPE.M with the given input arguments.
%
%      MSPC_SPE('Property','Value',...) creates a new MSPC_SPE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MSPC_SPE_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MSPC_SPE_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MSPC_SPE

% Last Modified by GUIDE v2.5 26-Mar-2017 16:21:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MSPC_SPE_OpeningFcn, ...
                   'gui_OutputFcn',  @MSPC_SPE_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MSPC_SPE is made visible.
function MSPC_SPE_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MSPC_SPE (see VARARGIN)

% Choose default command line output for MSPC_SPE
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%% Score scattered plot for the two first components
mainGuiInput = find(strcmp(varargin, 'title'));
sTitle = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'phase'));
phase = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 't'));
t = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'A'));
A = varargin{mainGuiInput+1};
set(handles.lblNumberPCs,'string',['Number of selected PCs: ' num2str(A)]);
mainGuiInput = find(strcmp(varargin, 'SPE'));
SPE = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'SPE_UCL_01'));
SPE_UCL_01 = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'SPE_UCL_05'));
SPE_UCL_05 = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'Enew'));
Enew = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'EnewSquared'));
EnewSquared = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'VariableNames'));
VariableNames = varargin{mainGuiInput+1};
VariableNames = VariableNames(:);
mainGuiInput = find(strcmp(varargin, 'IdRemovedObs'));
idRemovedObs = [];
if ~isempty(mainGuiInput)
    idRemovedObs = varargin{mainGuiInput+1};
end

tTemp = t(1:size(SPE,1));
plot(handles.axes_SPE,tTemp,SPE,'b-d','MarkerSize',5,'MarkerFaceColor','b');
hold(handles.axes_SPE,'on');
if ~isempty(idRemovedObs)
    indRemovedObs = ismember(tTemp,idRemovedObs);
    % Plot removed obs in red ..
    plot(handles.axes_SPE,tTemp(indRemovedObs),SPE(indRemovedObs),'r*','MarkerSize',5);
end
axis(handles.axes_SPE,[tTemp(1) tTemp(end) min(SPE) max(SPE)]);
axis(handles.axes_SPE,'auto y');
set(gcf,'Name',sTitle);
axes(handles.axes_SPE);
xlabel('t');
ylabel('SPE');
line([tTemp(1) tTemp(end)], [SPE_UCL_01 SPE_UCL_01],'Color','r','LineStyle','--','LineWidth',1);
line([tTemp(1) tTemp(end)], [SPE_UCL_05 SPE_UCL_05],'Color','r','LineStyle','-','LineWidth',1);
grid(handles.axes_SPE,'on');
grid(handles.axes_SPE,'minor');
hold(handles.axes_SPE,'off');

hdt = datacursormode;
set(hdt,'DisplayStyle','window');
% Declare a custom datatip update function to display data:
set(hdt,'UpdateFcn',{@labeldtips,handles,phase,t,SPE,SPE_UCL_01,SPE_UCL_05,Enew,EnewSquared,VariableNames})

if phase==1
    pos = get(gcf, 'Position');
    pos(3) = 122;
    set(gcf, 'Position', pos);
else
    LabelVariables(handles,VariableNames)
end
set(gcf, 'Resize', 'off');
% UIWAIT makes MSPC_SPE wait for user response (see UIRESUME)
% uiwait(handles.figSPEchart);

%uiwait(hObject);


% --- Outputs from this function are returned to the command line.
function varargout = MSPC_SPE_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function output_txt = labeldtips(obj,event_obj,handles,phase,t,SPE,SPE_UCL_01,SPE_UCL_05,Enew,EnewSquared,VariableNames)
% Display an observation's Y-data and label for a data tip
% obj          Currently not used (empty)
% event_obj    Handle to event object
% xydata       Entire data matrix
% labels       State names identifying matrix row
% xymean       Ratio of y to x mean (avg. for all obs.)
% output_txt   Datatip text (string or string cell array)
% This datacursor callback calculates a deviation from the
% expected value and displays it, Y, and a label taken
% from the cell array 'labels'; the data matrix is needed
% to determine the index of the x-value for looking up the
% label for that row. X values could be output, but are not.

c_axes = get(event_obj.Target,'Parent');
if c_axes==handles.axes_SPE
    pos = event_obj.Position;
    x = pos(1);
    y = pos(2);
    output_txt = {['t = ' num2str(x) ' min; SPE = ' num2str(y,4)]};
    if y > SPE_UCL_05
        output_txt{end+1} = ['Out of control'];
    elseif y > SPE_UCL_01
        output_txt{end+1} = ['Out of control'];
    end

    if phase==2
        % Phase II.Contribution to SPE
        idObs = find(t==x);
        bar(handles.axes_Cont,(EnewSquared(idObs,:).*sign(Enew(idObs,:))));
        LabelVariables(handles,VariableNames)
        grid(handles.axes_Cont,'on');
    end
else
    pos = event_obj.Position;
    x = pos(1);
    y = pos(2);
    output_txt = {['cont(' VariableNames{x} ') = ' num2str(y,4)]};
end

% --- Executes during object creation, after setting all properties.
function figSPEchart_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figSPEchart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

function LabelVariables(handles,VariableNames)
set(handles.axes_Cont,'fontsize',8);
ylabel(handles.axes_Cont,'Contribution')
% Set the X-Tick locations ...
nVars = length(VariableNames);
Xt = 1:nVars;
Xl = [1 nVars];
set(handles.axes_Cont,'XTick',Xt,'XLim',Xl);
% Check Matlab version
v = sscanf (version, '%d.%d.%d');
if v(1)<8 || (v(1)==8 && v(2)<4)
    % Before R2014b
    ax = axis(handles.axes_Cont);
    axis(axis); % Set the axis limit modes (e.g. XLimMode) to manual
    Yl = ax(3:4); % Y-axis limits
    % Place the text labels
    t = text(Xt,((Yl(1)-(Yl(2)-Yl(1))/50))*ones(1,length(Xt)),VariableNames, 'Parent',handles.axes_Cont,'FontSize',8);
    set(t,'HorizontalAlignment','right','VerticalAlignment','middle', 'Rotation',90);
    % Remove the default labels
    set(handles.axes_Cont,'XTickLabel','')
    % Get the Extent of each text object. This loop is unavoidable.
    for i = 1:length(t)
        ext(i,:) = get(t(i),'Extent');
    end
    % Determine the lowest point. The X-label will be placed so that the top is aligned with this point.
    LowYPoint = min(ext(:,2));
    % Place the axis label at this point
    XMidPoint = Xl(1)+abs(diff(Xl))/2;
    tl = text(XMidPoint,LowYPoint,'Variables', 'VerticalAlignment','top', 'HorizontalAlignment','center', 'Parent',handles.axes_Cont);
else
    % R2014b and later
    set(handles.axes_Cont,'XTickLabel',VariableNames, ...
                          'XTickLabelRotation',  90);
end
