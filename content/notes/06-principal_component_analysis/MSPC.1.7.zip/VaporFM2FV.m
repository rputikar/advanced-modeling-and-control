
function [sys,x0,str,ts] = VaporFM2FV(t,x,u,flag)
%qFactor_S_Function: Calculates q factor from composition z and temperature T

switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes();

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%
  % Unhandled flags %
  %%%%%%%%%%%%%%%%%%%
  case { 2, 4, 9 },
    sys = [];

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end
% end csfunc

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes()

sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = [];


%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% Specify the block simStateCompliance. The allowed values are:
%    'UnknownSimState', < The default setting; warn and assume DefaultSimState
%    'DefaultSimState', < Same sim state as a built-in block
%    'HasNoSimState',   < No sim state
%    'DisallowSimState' < Error out when saving or restoring the model sim
%    state
% end mdlInitializeSizes
%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)

sys = [];

% end mdlDerivatives
%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)

%Data
%********************************
VLEdata = load('VLEdata.mat');
xA = VLEdata.xA;
Tbubble = VLEdata.Tbubble;
% Tdew = VLEdata.Tdew;

% M_methanol = VLEdata.M_methanol;
% M_ethanol = VLEdata.M_ethanol;
% CpL_methanol = VLEdata.CpL_methanol;
% CpL_ethanol = VLEdata.CpL_ethanol;
% CpV_methanol = VLEdata.CpV_methanol;
% CpV_ethanol = VLEdata.CpV_ethanol;
% Tn_methanol = VLEdata.Tn_methanol;
% Tn_ethanol = VLEdata.Tn_ethanol;
% Tc_methanol = VLEdata.Tc_methanol;
% Tc_ethanol = VLEdata.Tc_ethanol;
% Hv_methanol = VLEdata.Hv_methanol;
% Hv_ethanol = VLEdata.Hv_ethanol;
%********************************


%Calculate T from x value:
x = u(1);
if x < min(xA)
    %ODE could temporary lead to absurd composition values
    x = min(xA);
elseif x > max(xA)
    x = max(xA);
end;

FM = u(2);% kmol/min
T = interp1(xA,Tbubble,x);
P = 1; % atm
R = 0.08205;% atm L / K mol
T = T + 273.15; % K
FV = FM*R*T*60000/P; % L/h
%fprintf('x=%s; FM=%s; T=%s; FV=%s;  \n',num2str(x),num2str(FM),num2str(T), num2str(FV));

    
sys = FV;

% end mdlOutputs
