function varargout = MSPC_scores(varargin)
% MSPC_SCORES M-file for MSPC_scores.fig
%      MSPC_SCORES, by itself, creates a new MSPC_SCORES or raises the existing
%      singleton*.
%
%      H = MSPC_SCORES returns the handle to a new MSPC_SCORES or the handle to
%      the existing singleton*.
%
%      MSPC_SCORES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MSPC_SCORES.M with the given input arguments.
%
%      MSPC_SCORES('Property','Value',...) creates a new MSPC_SCORES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MSPC_scores_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MSPC_scores_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MSPC_scores

% Last Modified by GUIDE v2.5 30-Nov-2014 17:22:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MSPC_scores_OpeningFcn, ...
                   'gui_OutputFcn',  @MSPC_scores_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MSPC_scores is made visible.
function MSPC_scores_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MSPC_scores (see VARARGIN)

% Choose default command line output for MSPC_scores
handles.output = hObject;


%% Score scattered plot for the two first components
% Parameters
mainGuiInput = find(strcmp(varargin, 'title'));
sTitle = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'phase'));
handles.phase = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 't'));
handles.t = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'A'));
handles.A = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'N'));
handles.N = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'T'));
handles.T = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'L'));
handles.L = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'P'));
handles.P = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'X'));
handles.X = varargin{mainGuiInput+1};
mainGuiInput = find(strcmp(varargin, 'VariableNames'));
handles.VariableNames = varargin{mainGuiInput+1};
% Combos for PC1 and PC2: only till A components
cComponents = num2cell(1:handles.A);
set(handles.cmbPC1,'String',cComponents, ...
                   'Value',1);
set(handles.cmbPC2,'String',cComponents, ...
                   'Value',2);
% Plot scores
set(hObject,'Name',sTitle);
if handles.phase==1
    pos = get(hObject, 'Position');
    pos(3) = 122;
    set(hObject, 'Position', pos);
end
set(hObject, 'Resize', 'off');
plot_scores(handles);
% Update handles structure
guidata(hObject, handles);


function plot_scores(handles)
% Parameters
T = handles.T;
N = handles.N;
L = handles.L;
% Plot
axes(handles.axes_Scores)
% Current PCs to plot ...
iPC1 = get(handles.cmbPC1,'Value');
iPC2 = get(handles.cmbPC2,'Value');
% Update component combo ...
set(handles.cmbComponent,'String',{iPC1,iPC2}, ...
                         'Value',1);
% Plot scores ...
plot(handles.axes_Scores,T(:,iPC1),T(:,iPC2),'+')
grid on;
xlabel(['t' num2str(iPC1)])
ylabel(['t' num2str(iPC2)])

% The confidence region for a two dimensional score plot of dimension a and b is an ellipse with axis:
alpha = 0.05;
F = finv(1-alpha,2,N-2);
axis1 = sqrt(L(1)*F*2*(N^2-1)/(N*(N-2)));
axis2 = sqrt(L(2)*F*2*(N^2-1)/(N*(N-2)));
rectangle('Position',[-axis1,-axis2,2*axis1,2*axis2],'Curvature',[1,1], 'EdgeColor','r');

alpha = 0.01;
F = finv(1-alpha,2,N-2);
axis1 = sqrt(L(1)*F*2*(N^2-1)/(N*(N-2)));
axis2 = sqrt(L(2)*F*2*(N^2-1)/(N*(N-2)));
rectangle('Position',[-axis1,-axis2,2*axis1,2*axis2],'Curvature',[1,1], 'EdgeColor','r','LineStyle','--');

grid(handles.axes_Scores,'minor');
if handles.phase==2
    hdt = datacursormode;
    set(hdt,'DisplayStyle','window');
    % Declare a custom datatip update function to display data:
    set(hdt,'UpdateFcn',{@labeldtips,handles})
end

% UIWAIT makes MSPC_scores wait for user response (see UIRESUME)
% uiwait(handles.MSPC_scores);

%uiwait(hObject);


% --- Outputs from this function are returned to the command line.
function varargout = MSPC_scores_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function output_txt = labeldtips(obj,event_obj,handles)
% Display an observation's Y-data and label for a data tip
% obj          Currently not used (empty)
% event_obj    Handle to event object
% xydata       Entire data matrix
% labels       State names identifying matrix row
% xymean       Ratio of y to x mean (avg. for all obs.)
% output_txt   Datatip text (string or string cell array)
% This datacursor callback calculates a deviation from the
% expected value and displays it, Y, and a label taken
% from the cell array 'labels'; the data matrix is needed
% to determine the index of the x-value for looking up the
% label for that row. X values could be output, but are not.

% Parameters
t = handles.t;
T = handles.T;

c_axes = get(event_obj.Target,'Parent');
if c_axes~=handles.axes_Scores
    return;
end

pos = event_obj.Position;
x = pos(1); % 1st component
y = pos(2); % 2nd component

iPC1 = get(handles.cmbPC1,'Value');
Tx = T(:,iPC1);
iPC2 = get(handles.cmbPC2,'Value');
Ty = T(:,iPC2);

handles.idObs = find(Tx==x & Ty==y);

output_txt = {['t = ' num2str(t(handles.idObs)) ' min']};
output_txt{end+1} = ['t1 = ' num2str(x) '; t2 = ' num2str(y)];

guidata(handles.cmbComponent, handles);

PlotContribution(handles);



% --- Executes during object creation, after setting all properties.
function figSPEchart_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figSPEchart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in cmbComponent.
function cmbComponent_Callback(hObject, eventdata, handles)
% hObject    handle to cmbComponent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cmbComponent contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cmbComponent
PlotContribution(handles);


% --- Executes during object creation, after setting all properties.
function cmbComponent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmbComponent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PlotContribution(handles)
P = handles.P;
X = handles.X;
idObs = handles.idObs;
a = get(handles.cmbComponent,'value');
%Plot contribution of the scores for the observation number 'idObs'
axes(handles.axes_Cont)
%The contribution of each original 'k' variable to the 'a' score for the
%idObs observation is ...
for k=1:size(P)
    cont(k) = P(k,a) * X(idObs,k);
end
bar(handles.axes_Cont,cont);
LabelVariables(handles)
grid(handles.axes_Cont,'on');


function LabelVariables(handles)
VariableNames = handles.VariableNames;
set(handles.axes_Cont,'fontsize',8);
ylabel(handles.axes_Cont,'Contribution')
% Set the X-Tick locations ...
Xt = 1:size(VariableNames,1);
Xl = [1 size(VariableNames,1)];
set(handles.axes_Cont,'XTick',Xt,'XLim',Xl);
% Check Matlab version
v = sscanf (version, '%d.%d.%d');
if v(1)<8 || (v(1)==8 && v(2)<4)
    % Before R2014b
    ax = axis; % Current axis limits
    axis(axis); % Set the axis limit modes (e.g. XLimMode) to manual
    Yl = ax(3:4); % Y-axis limits
    % Place the text labels
    t = text(Xt-20/size(VariableNames,1),((Yl(1)-(Yl(2)-Yl(1))/50))*ones(1,length(Xt)),VariableNames);
    set(t,'HorizontalAlignment','right','VerticalAlignment','top', 'Rotation',90);
    % Remove the default labels
    set(gca,'XTickLabel','')
    % Get the Extent of each text object. This loop is unavoidable.
    for i = 1:length(t)
        ext(i,:) = get(t(i),'Extent');
    end
    % Determine the lowest point. The X-label will be placed so that the top is aligned with this point.
    LowYPoint = min(ext(:,2));
    % Place the axis label at this point
    XMidPoint = Xl(1)+abs(diff(Xl))/2;
    tl = text(XMidPoint,LowYPoint,'Variables', 'VerticalAlignment','top', 'HorizontalAlignment','center');
else
    % R2014b and later
    set(handles.axes_Cont,'XTickLabel',VariableNames, ...
                          'XTickLabelRotation',  45);
end

% --- Executes during object creation, after setting all properties.
function MSPC_scores_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MSPC_scores (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in cmbPC1.
function cmbPC1_Callback(hObject, eventdata, handles)
% hObject    handle to cmbPC1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cmbPC1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cmbPC1


% --- Executes during object creation, after setting all properties.
function cmbPC1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmbPC1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cmbPC2.
function cmbPC2_Callback(hObject, eventdata, handles)
% hObject    handle to cmbPC2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cmbPC2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cmbPC2


% --- Executes during object creation, after setting all properties.
function cmbPC2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmbPC2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cmdRefresh.
function cmdRefresh_Callback(hObject, eventdata, handles)
% hObject    handle to cmdRefresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

plot_scores(handles);
