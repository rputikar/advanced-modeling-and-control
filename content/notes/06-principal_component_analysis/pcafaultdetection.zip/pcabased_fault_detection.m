function pcabased_fault_detection(z0,z1)
% PCA-based Fault Detection
%
% Inputs:   z0 [N x 2] = training data
%           z1 [N x 2] = test data
% where:    N          = number of samples
%
% This code visualizes how PCA can account 
% for multivariate data in fault detection.
% It also uses MATLAB's ksdensity for 
% estimating the data PDF, so as to compute
% a T^2-based upper control limit.
%
% simpledata.mat has sample temperature [K]
%     and concentration [mol/L] data from
%     the contents of a simulated CSTR.
%
% The output are plots of the raw data,
%     normalized data, and PCA projected data.
%     Also, rings representing the T^2-based
%     upper control limits at different user-
%     defined confidence levels are plotted.
%
% You can edit confidence limits at Line 77.
%
% This code is intended for educational purposes.
%
% Load simpledata.mat and run the following:
% >> pcabased_fault_detection(train,test)

%% Get 2D data
close all; clc;
N = length(z0);

% Plot results
fig = figure(1); subplot(221);
set(fig,'defaultLegendAutoUpdate','off');    % For R2017a users and above
plot(z0(:,1),z0(:,2),'b.','MarkerSize',8);
ylabel('Temp [K]'); xlabel('Conc. [mol/L]'); hold on; 
plot(z1(:,1),z1(:,2),'m.','MarkerSize',8);
title('Raw Data'); hold off; grid on;
legend('Training data','Test data');    

%% After Normalization
zmean = mean(z0); zstd = std(z0);
z0 = (z0 - zmean(ones(N,1),:))./zstd(ones(N,1),:);  % Normalize training z
z1 = (z1 - zmean(ones(N,1),:))./zstd(ones(N,1),:);  % Normalize test z

% Plot results
figure(1); subplot(222);
plot(z0(:,1),z0(:,2),'b.','MarkerSize',8);
ylabel('Temp [K]'); xlabel('Conc. [mol/L]'); hold on; 
plot(z1(:,1),z1(:,2),'m.','MarkerSize',8);
hold off; grid on; title('Normalized Data');
legend('Training data','Test data');

%% After PCA transformation
[V,D,~] = eig(z0'*z0/(N-1));                % Eigenvalue decomposition
[S,sj] = sort(diag(D),'descend');           % Sort eigenvalues
V = V(:,sj); S = S';                        % Re-arrange eigenvectors
z0 = z0*V; z1 = z1*V;                       % Project data to latent space

% Plot results
figure(1); subplot(223); 
plot(z0(:,1),z0(:,2),'b.','MarkerSize',8);
ylabel('PC 2'); xlabel('PC 1'); hold on; 
plot(z1(:,1),z1(:,2),'m.','MarkerSize',8);
hold off; grid on; title('After PCA (rotation)');
legend('Training data','Test data');

z0 = z0.*(S(ones(N,1),:).^-0.5);
z1 = z1.*(S(ones(N,1),:).^-0.5);

figure(1); subplot(224);
plot(z0(:,1),z0(:,2),'b.','MarkerSize',8)
ylabel('PC 2'); xlabel('PC 1'); hold on; 
plot(z1(:,1),z1(:,2),'m.','MarkerSize',8);
hold off; grid on; axis equal;
title('After PCA (rotation + scaling)');
legend('Training data','Test data'); 

%% Generate T2 bounds using KDE
mons = sum(z0.^2,2);                        % Scalarize at each time
[Ap.f,Ap.x] = ksdensity(mons);              % Estimate PDF of scalars
Af = cumsum([0;diff(Ap.x(:))].*Ap.f(:));    % Numerical integration on PDF
conf = [0.99 0.95 0.90];                    % Confidence limits (edit me!)

for j = 1:length(conf)
    T2ucl = max(Ap.x(Af<=conf(j)));         % Get T2 upper control limit

    % Plot ellipse on the projected data
    t = 0:0.01:2*pi; T = length(t);         % Set theta in [0, 2*pi]
    LIM = zeros(T,2);
    LIM(:,1) = sqrt(T2ucl)*cos(t');         % Compute x's of UCL ring
    LIM(:,2) = sqrt(T2ucl)*sin(t');         % Compute y's of UCL ring

    figure(1); subplot(224); hold on;       % Refer to 4th subplot
    plot(LIM(:,1),LIM(:,2),'r'); hold off;  % Plot the UCL ring

    figure(1); subplot(223); hold on;       % Refer to 3rd subplot
    LIM = LIM.*(S(ones(T,1),:).^0.5);       % Stretch UCL ring by sqrt(S)
    plot(LIM(:,1),LIM(:,2),'r'); hold off;  % Plot the UCL ring

    figure(1); subplot(222); hold on;       % Refer to 2nd subplot
    LIM = LIM/V;                            % Rotate the UCL ring
    plot(LIM(:,1),LIM(:,2),'r'); hold off;  % Plot the UCL ring
    
    figure(1); subplot(221); hold on;       % Refer to 1st subplot
    LIM = LIM.*zstd(ones(T,1),:) +...
        zmean(ones(T,1),:);                 % Un-normalize the UCL ring
    plot(LIM(:,1),LIM(:,2),'r'); hold off;  % Plot the UCL ring
end

end
